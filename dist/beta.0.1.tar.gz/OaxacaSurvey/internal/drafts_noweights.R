# Example 2: logistic models with multilevel categorical covariates
# Real data  from Spain's Encuesta Financiera de Familias (2002-2020)


  weighted_means <- function(design, relevant_vars) {
  means <- sapply(design[relevant_vars], mean, na.rm = TRUE)
    return(means)
  }
  # Core function without bootstrapping
  oaxaca_blinder_core <- function(data, formula, group, weights, method) {
    exclude_cols <- c("y", "group", "weights")
    if (method == "logit") {
      fam <- quasibinomial(link = "logit")
    }
    if (method == "normal") {
      fam <- gaussian(link = "identity")
    }

    # Split 2 distinct control groups
    data1 <- data[data$group == 1, ]
    data2 <- data[data$group == 0, ]

    # Define survey design accounting for sample weights and other characteristics
    des1 <- data.frame(data1)
    des2 <- data.frame(data2)

    # Estimate svygml model accounting for survey design
    model1 <- lm(formula, data = data1)
    model2 <- lm(formula, data = data2)

    # Obtain weighted means for needed variables
    relevant_vars <- names(des1[!names(des1) %in% exclude_cols])
    means1 <- weighted_means(des1, relevant_vars)
    means2 <- weighted_means(des2, relevant_vars)
    means1_y <- weighted_means(des1, "y")
    means2_y <- weighted_means(des2, "y")

    # Calculate predicted probabilities for logistic regression
    predicted_prob <- function(coef, means) {
      exp(sum(coef * c(1, means))) / (1 + exp(sum(coef * c(1, means))))
    }

    if (method == "logit") {
      # Calculate endowments effect without intercept
      endowments <- predicted_prob(coef(model2), means1) - predicted_prob(coef(model2), means2)
      # Calculate coefficients effect without intercept
      coefficients <- predicted_prob(coef(model1), means2) - predicted_prob(coef(model2), means2)
      # Calculate interaction effect without intercept
      interaction <- predicted_prob(coef(model1), means1 - means2) - predicted_prob(coef(model2), means1 - means2)
      # Calculate unexplained effect (intercept difference)
      unexplained <- 0

      # Total difference
      total <- endowments + coefficients + interaction + unexplained
    }
    if (method == "normal") {
      # Extract decomposition (as originally done for the "normal" method)
      endowments <- - sum(coef(model1)[-1] * (means1 - means2))
      coefficients <- - sum((coef(model1)[-1] - coef(model2)[-1]) * means1) - unname(coef(model1)[1] - coef(model2)[1])
      interaction <- sum((coef(model1)[-1] - coef(model2)[-1]) * (means1 - means2))
      unexplained <- 0
      total <- endowments + coefficients + interaction + unexplained
    }

    if (method == "normal_alt") {
      # Extract decomposition (as originally done for the "normal" method)
      endowments <- sum(coef(model2)[-1] * (means1 - means2))
      coefficients <- sum((coef(model1)[-1] - coef(model2)[-1]) * means2)
      interaction <- sum((coef(model1)[-1] - coef(model2)[-1]) * (means1 - means2))
      unexplained <- unname(coef(model1)[1] - coef(model2)[1])
      total <- endowments + coefficients + interaction + unexplained
    }
    # Return decomposition
    return(
      c(
        unex = unexplained, end = endowments, coef = coefficients, inter = interaction, total = total,
        means1 = means1_y, means2 = means2_y, means_dif = (means1_y - means2_y)
      )
    )
  }



library(fastDummies) # to transform multi-level categories into dummies

library(data.table) # optional, for data import and handling
library(magrittr) # optional, for piping with %>%


# Import dataset with multilevel categorical data from a s
df <- fread("tests/eff-pool-2002-2020.csv")
df <- df[sv_year %in% c(2002, 2020)]
df[, group := 0][class == "worker" & sv_year == 2002, group := 0][class == "worker" & sv_year == 2020, group := 1]
df[, rentsbi := 0][rents >= renthog * 0.1 & rents > 2000, rentsbi := 1]
df[, facine3_fake := 1]
df[homeowner == "", homeowner := "Non-Owner"]
df$class <- relevel(as.factor(df$class), ref = "self-employed")
df$bage <- relevel(as.factor(df$bage), ref = "0-34")
df$inherit <- relevel(as.factor(df$inherit), ref = "Non-inherit")
df$homeowner <- relevel(as.factor(df$homeowner), ref = "Non-Owner")
df$riquezafin <- factor(as.logical(df$riquezafin), levels = c(TRUE, FALSE), labels = c("Fin", "NonFin"))
total_variables <- c(
  "facine3", "renthog", "renthog1", "bage", "homeowner", "worker", "young", "sex", "class",
  "actreales", "riquezanet", "riquezafin", "educ", "auton", "class",
  "tipo_auton", "direc", "multipr", "useprop", "inherit"
)
selected_variables <- c(
  "renthog", "bage", "sex", "homeowner", "riquezafin"
)

####################################################################################

# select regressors
data <- df[, ..selected_variables]

# transform multi-level categories to dummies. IMPORTANT remove both first dummy and selected column to get OB decomposition!
data <- fastDummies::dummy_cols(data,
  select_columns = c("bage", "sex", "homeowner", "riquezafin"),
  remove_first_dummy = TRUE,
  remove_selected_columns = TRUE
)

# name the columns as x1....xn for oaxaca-blinder survey
colnames(data) <- paste0("x", seq_along(colnames(data)))
length_reg <- length(colnames(data))
new_formula <- paste("y ~", paste0("x", 1:length_reg, collapse = " + "))

# compose the final dataset by adding: engenous variable, groups of split and sample weights
data <- cbind(y = df$rentsbi, group = df$group, weights = df$facine3_fake, data)
set.seed(123)


# finally, test the model
result <- oaxaca_blinder_core(
  as.formula(new_formula),
  data = data.frame(data),
  group = "group",
  weights = "weights",
  method = "normal"
)

# Return Oaxaca-Blinder decomposition with bootestraped CI
result %>% print()

##############

result3 <- oaxaca::oaxaca(
  formula = rentsbi ~ renthog + bage + sex + homeowner + riquezafin | group,
  data = df,
  R = 2,
  reg.fun = function(formula, data, ...) {
    lm(formula, data = data)
  }
)
coefficients <- result3$threefold$overall[c(1,3,5)] %>% unlist()
c(data.table(coefficients), sum = sum(coefficients), result3$y) %>% print()
print(result3$y)

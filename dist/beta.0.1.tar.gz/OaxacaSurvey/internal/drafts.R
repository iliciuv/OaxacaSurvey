# Example 2: logistic models with multilevel categorical covariates
# Real data  from Spain's Encuesta Financiera de Familias (2002-2020)

library(OaxacaSurvey) # latest version of this package
library(fastDummies) # to transform multi-level categories into dummies

library(data.table) # optional, for data import and handling
library(magrittr) # optional, for piping with %>%
library(survey)

# Import dataset with multilevel categorical data from a s
df <- fread("tests/eff-pool-2002-2020.csv")
v_rentsbi <- c()
years <- c(2002, 2005, 2008, 2011, 2014, 2017, 2020)
cpi <- c(73.31, 80.44, 89.11, 93.35, 96.82, 97.98, 100) / 100

for (i in seq_along(years)) {
  df[sv_year == years[i], rentsbi := 0][rents >= renthog * 0.1 & rents * cpi[i] > 2000, rentsbi := 1]
}
####################################################################################
for (year in seq_along(years)) {
  df1 <- df[class == "worker" & sv_year == years[year]]
  df_svy <- svydesign(ids = ~1, data = data.frame(df1), weights = df1$facine3)
  v_rentsbi[year] <- svymean(~rentsbi, design = df_svy)
}

object <- cbind(c(2002, 2005, 2008, 2011, 2014, 2017, 2020), v_rentsbi)

print(object)

# INSERT LOGISCIC INTO SVYMEAN

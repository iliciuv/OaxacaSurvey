# OaxacaSurvey
an r test package implementing the oaxaca-blinder decomposition for survey objects, that is, taking sample weights into consideration by means of svyglm


### Important
To install deprecated package boost download source from: https://cran.r-project.org/src/contrib/Archive/boost/

And then, pointing to the directory containing the file install it with:

```r

install.packages("/home/other/dev/open-source-collab/OaxacaSurvey/dep/boost_1.0-0.tar.gz", type="source")

```r